#!/bin/sh
# Minimal keepalive script (POSIX sh)
# - Very low overhead: uses only shell builtins and coreutils date/printf
# - Use environment variables or args to configure interval/log paths

INTERVAL=${1:-${INTERVAL:-60}}
LOG=${2:-keepalive.log}
TOUCH=${3:-keepalive.timestamp}

trap 'echo "keepalive.sh: stopping"; exit 0' INT TERM

echo "keepalive.sh starting. interval=${INTERVAL}s, log=${LOG}, touch=${TOUCH}"

while :; do
  TS=$(date -Iseconds)
  printf "%s heartbeat\n" "$TS" >> "$LOG" 2>/dev/null || printf "%s heartbeat (log write failed)\n" "$TS" >&2
  printf "%s\n" "$TS" > "$TOUCH" 2>/dev/null || printf "%s (touch write failed)\n" "$TS" >&2
  sleep "$INTERVAL"
done
