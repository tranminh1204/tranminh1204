Simple keepalive program

What it does
- Periodically writes a heartbeat timestamp to `keepalive.log` and updates `keepalive.timestamp`.
- Handles SIGINT/SIGTERM for graceful shutdown.
- Can run forever or for a limited number of iterations (useful for testing).

Build

g++ -std=c++17 -O2 test.cpp -o keepalive

Run (daemon-like)

./keepalive --interval 60

Run for testing (3 iterations, 1s interval)

./keepalive --interval 1 --iterations 3

systemd service example

[Unit]
Description=Keepalive for codebase

[Service]
ExecStart=/path/to/repo/keepalive --interval 60
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target

Replace /path/to/repo with the absolute path to this repository when creating the service file.

Notes
- The program is intentionally small and portable. Redirect logs or run under a process supervisor (systemd, Docker, supervisord) for production usage.
